const s="/assets/about-flower-CmUEGsyy.webp";export{s as F};
